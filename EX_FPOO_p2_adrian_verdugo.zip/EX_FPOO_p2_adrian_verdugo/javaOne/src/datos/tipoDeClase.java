package datos;

/**
 *
 * @author Adrian Verdugo
 */

public enum tipoDeClase {
    
    // @description: clase de pasaje mas barato
    ECONOMICO,
    
    // @description : clase de pasaje de primer nivel
    EJECUTIVO
    
}
