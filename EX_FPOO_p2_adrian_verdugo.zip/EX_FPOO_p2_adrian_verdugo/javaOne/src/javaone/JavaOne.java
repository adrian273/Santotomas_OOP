package javaone;
import negocio.Vuelo;
/**
 *
 * @author Adrian Verdugo
 * @since 28-10-2017
 * @version 0.1
 */
public class JavaOne {

    public static void main(String[] args) {
        Vuelo vuelo = new Vuelo();
        vuelo.main();
    }
    
}
